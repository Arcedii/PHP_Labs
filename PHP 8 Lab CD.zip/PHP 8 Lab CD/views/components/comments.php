<?php

$commentsFile = __DIR__ . '/comments.txt';

if (file_exists($commentsFile)) {
    $comments = file($commentsFile);

    foreach ($comments as $comment) {
        echo "<p>$comment</p>";
    }
} else {
    echo '<p>Комментариев нет.</p>';
}
