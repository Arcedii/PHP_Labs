<h2>Форма комментариев</h2>
<form action="/handlers/form-handler.php" method="post">
    <label for="name">Имя:</label>
    <input type="text" id="name" name="name" required>

    <label for="comment">Комментарий:</label>
    <textarea id="comment" name="comment" required></textarea>

    <button type="submit">Отправить</button>
</form>
