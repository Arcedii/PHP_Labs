<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>PHP Фреймворк</title>
</head>
<body>
    <header>
        <h1>Заголовок</h1>
    </header>

    <main>
        <?php include __DIR__ . '/components/form.php'; ?>

        <?php include __DIR__ . '/components/comments.php'; ?>
    </main>

    <footer>
        <p>&copy; 2024</p>
    </footer>
</body>
</html>
