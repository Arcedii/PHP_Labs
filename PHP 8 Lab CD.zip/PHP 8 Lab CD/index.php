<?php

include __DIR__ . '/views/index.php';
