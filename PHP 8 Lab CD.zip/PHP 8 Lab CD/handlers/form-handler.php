<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $comment = $_POST['comment'];

    // Сохранение данных формы в файл (например, в comments.txt)
    $file = fopen(__DIR__ . '/comments.txt', 'a');
    fwrite($file, "$name: $comment\n");
    fclose($file);

    // Перенаправление на главную страницу
    header('Location: /');
    exit;
}
